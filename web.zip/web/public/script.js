function actualizarCuentaRegresiva() {
    const lanzamiento = new Date('March 20, 2025 00:00:00').getTime();
    const ahora = new Date().getTime();
    const diferencia = lanzamiento - ahora;

    const dias = Math.floor(diferencia / (1000 * 60 * 60 * 24));
    const horas = Math.floor((diferencia % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutos = Math.floor((diferencia % (1000 * 60 * 60)) / (1000 * 60));
    const segundos = Math.floor((diferencia % (1000 * 60)) / 1000);

    // Inserta la estructura HTML en el div countdown
    document.getElementById('countdown').innerHTML = `
        <div class="time-box">
            <span id="days">${dias}</span>
            <span class="label">Días</span>
        </div>
        <div class="time-box">
            <span id="hours">${horas}</span>
            <span class="label">Horas</span>
        </div>
        <div class="time-box">
            <span id="minutes">${minutos}</span>
            <span class="label">Minutos</span>
        </div>
        <div class="time-box">
            <span id="seconds">${segundos}</span>
            <span class="label">Segundos</span>
        </div>
    `;
}

// Llamar a la función inmediatamente y actualizar cada segundo
actualizarCuentaRegresiva();
setInterval(actualizarCuentaRegresiva, 1000);
$(document).ready(function(){

    document.getElementById("btnSend").addEventListener("click", function() {
        let name = document.getElementById("names").value.trim();
        let email = document.getElementById("email").value.trim();
        let message = document.getElementById("mensaje").value.trim();
        let statusMessage = document.getElementById("statusMessage");

        // Validación de campos
        if (name === "" || email === "" || message === "") {
            statusMessage.style.color = "red";
            statusMessage.textContent = "Todos los campos son obligatorios.";
            return;
        }

        // Validación de correo electrónico
        let emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        if (!emailPattern.test(email)) {
            statusMessage.style.color = "red";
            statusMessage.textContent = "Ingrese un correo válido.";
            return;
        }

        // Enviar datos al servidor
        let formData = {
            name: name,
            email: email,
            message: message
        };

        fetch("/send-message", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(formData)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                statusMessage.style.color = "green";
                statusMessage.textContent = "Mensaje enviado con éxito.";
                document.getElementById("names").value = "";
                document.getElementById("email").value = "";
                document.getElementById("mensaje").value = "";
            } else {
                statusMessage.style.color = "red";
                statusMessage.textContent = "Error al enviar el mensaje.";
            }
        })
        .catch(error => {
            statusMessage.style.color = "red";
            statusMessage.textContent = "Error en la conexión.";
            console.error("Error:", error);
        });
    });

});
// Seleccionamos todas las tarjetas de promoción
const promociones = document.querySelectorAll('.promocion');

// Añadimos un evento de clic a cada promoción
promociones.forEach(promocion => {
    const btnVerMas = promocion.querySelector('.btn-promocion');
    btnVerMas.addEventListener('click', (e) => {
        e.preventDefault(); // Evitar que el enlace se active
        promocion.classList.toggle('activa'); // Cambiar la visibilidad del contenido adicional
    });
});
